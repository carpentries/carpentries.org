#!/usr/bin/env python

import random
import math

count = 0
total = 500000000
for n in range(0,total):
  x = random.random()
  y = random.random()
  # print "x = ", x, " y = ", y
  z = math.hypot(x,y)
  if z < 1 : count +=1
print "pi is ~= ", 4.0 * count / total
