import sys
print sys.platform
print sys.version
print "Arguments are ", sys.argv
print "Number of argument is ", len(sys.argv)
for arg in sys.argv:
    print arg

print sys.argv[1]

