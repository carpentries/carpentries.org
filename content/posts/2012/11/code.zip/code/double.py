def double(x):
    return x * 2

print double(4)
print double("two")

