import sys
if (len(sys.argv) < 2): # Has the user specifed a file?
  sys.exit("Missing file name")
filename = sys.argv[1]
source = open(filename, 'r')
# Remove the header line from the file
source.readline()
number = 0
for line in source:
    if line.startswith("#"): # This line is a comment
        pass
    elif line.startswith("D"): # The header line
        pass
    else:
        number = number + 1
source.close()
print "The number of data records is:", number
