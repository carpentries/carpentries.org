def greet(name):
    return exclaim('Good morning ' + name)

def exclaim(str):
    return str + '!'

def double(num):
    return num * 2

def sign(num):
    ret = 0
    if (num > 0):
        ret = 1
    elif (num == 0):
        ret = 0
    else:
        ret = -1
    return ret

def for_each(func, list):
    ret = []
    for val in list:
        ret.append(func(val))
    return ret

#result = greet('steve')
#print result

vals = [-5, 0, 55]

print vals

signs = for_each(sign, vals)
#for val in vals:
#    signs.append(sign(val))

print signs

doubles = for_each(double, vals)
#for val in vals:
#    doubles.append(double(val))

print doubles

#print sign(45)
#print sign(0)
#print sign(-44)

#print double(4)
#print double('steve')
