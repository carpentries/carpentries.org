echo the answer should be 0
python intro.py comment.txt
echo the answer should be 0
python intro.py header.txt
echo the answer should be 1
python intro.py one.txt
echo the answer should be 4
python intro.py data.txt
