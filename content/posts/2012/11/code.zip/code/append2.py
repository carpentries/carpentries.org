def appender(a_string, a_list):
    a_string += 'turing'
    a_list.append('turing')

temp = 'alan'
list_val = ['alan']
appender(temp, list_val)

print temp
print list_val

