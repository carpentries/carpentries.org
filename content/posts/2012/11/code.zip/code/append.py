def append(str_var, list_var):
    str_var = str_var + " more"
    list_var.append('more')

str_var = "Some text"
list_var = ["one", "two", "three"]

append(str_var, list_var)
print str_var
print list_var

