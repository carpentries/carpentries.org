import csv
from datetime import datetime
from matplotlib import pyplot

#------------------------------------------------------------

def keep_line(line):
    # True if the line is not blank and not a comment
    return len(line.strip()) > 0 and not line.startswith("#")

#------------------------------------------------------------

def filter_lines(reader):
    lines = []

    for line in reader:
        if keep_line(line):
            lines.append(line)

    return lines

#------------------------------------------------------------

def parse_workouts(rows):
    workouts = []

    for row in rows:
        # Date format is "Year, Month-Day"
        date = datetime.strptime(row[0], "%Y, %b-%d")
        kind = row[1].strip()
        distance = int(row[2])
        time = int(row[3])

        workouts.append([date, kind, distance, time])

    return workouts

#------------------------------------------------------------

def extract_days(workouts):
    days = []

    for w in workouts:
        date = w[0]
        days.append(date.day)

    return days

#------------------------------------------------------------

def extract_times(workouts):
    times = []

    for w in workouts:
        times.append(w[3])

    return times

#------------------------------------------------------------

def plot(days, times, filename):

    # Create a new figure
    fig = pyplot.figure()

    # Add a title and label the axes
    pyplot.title("Times I worked out in March") 
    pyplot.xlabel("Day")
    pyplot.ylabel("Time (min)")

    # Make a "tick" mark for each day up
    # to the maximum day in our data set.
    pyplot.xticks(range(1, max(days)+1))

    # Put a grid behind the figure
    pyplot.grid()

    # Plot days vs. times with a thicker red line
    pyplot.plot(days, times, color="red", linewidth=2)

    # Save figure to filename (format is determined by
    # the file extension).
    pyplot.savefig(filename)

#------------------------------------------------------------

# Read workout data
reader = file("workout.csv", "r") 
lines = filter_lines(reader)
csv_reader = csv.reader(lines)

# Parse and extract
workouts = parse_workouts(csv_reader)
days = extract_days(workouts)
times = extract_times(workouts)

# Plot results
plot(days, times, "workout_times.png")

