import numpy as np
import matplotlib.pyplot as pyplot
from datetime import datetime
import os, calendar

event_types = ['Rain', 'Thunderstorm', 'Snow', 'Fog']
num_events = len(event_types)

def event2int(event):
    return event_types.index(event)

def date2int(date_str):
    date = datetime.strptime(date_str, '%Y-%m-%d')
    return date.toordinal()

def r_squared(actual, ideal):
    actual_mean = np.mean(actual)
    ideal_dev = np.sum([(val - actual_mean)**2 for val in ideal])
    actual_dev = np.sum([(val - actual_mean)**2 for val in actual])

    return ideal_dev / actual_dev

#-------------------------------------------------- 

def read_weather(file_name):
    dtypes = np.dtype({ 'names' : ('timestamp', 'max temp', 'mean temp', 'min temp', 'events'),
                        'formats' : [np.int, np.float, np.float, np.float, 'S100'] })

    data = np.loadtxt(file_name, delimiter=',', skiprows=1, 
            converters = { 0 : date2int },
            usecols=(0,1,2,3,21), dtype=dtypes)

    return data

#-------------------------------------------------- 

def temp_plot(dates, mean_temps, min_temps = None, max_temps = None):

    year_start = datetime(2012, 1, 1)
    days = np.array([(d - year_start).days + 1 for d in dates])

    fig = pyplot.figure()
    pyplot.title('Temperatures in Bloomington 2012')
    pyplot.ylabel('Mean Temperature (F)')
    pyplot.xlabel('Day of Year')

    if (max_temps is None or min_temps is None):
        pyplot.plot(days, mean_temps, marker='o')
    else:
        temp_err = np.vstack((mean_temps - min_temps,
                              max_temps - mean_temps))

        pyplot.errorbar(days, mean_temps, marker='o', yerr=temp_err)
        pyplot.title('Temperatures in Bloomington 2012 (max/min)')

    slope, intercept = np.polyfit(days, mean_temps, 1)
    ideal_temps = intercept + (slope * days)
    r_sq = r_squared(mean_temps, ideal_temps)

    fit_label = 'Linear fit ({0:.3f})'.format(slope)
    pyplot.plot(days, ideal_temps, color='red', linestyle='--', label=fit_label)
    pyplot.annotate('r^2 = {0:.3f}'.format(r_sq), (0.05, 0.9), xycoords='axes fraction')
    pyplot.legend(loc='lower right')

    return fig

#-------------------------------------------------- 

def hist_events(dates, events):
    event_months = []

    for i in range(num_events):
        event_months.append([])

    # Build up lists of months where events occurred
    min_month = 13
    max_month = 0

    for date, event_str in zip(dates, events):
        if len(event_str) == 0:
            continue  # Skip blank events

        month = date.month
        min_month = min(month, min_month)
        max_month = max(month, max_month)

        for event in event_str.split('-'):
            event_code = event2int(event)
            event_months[event_code].append(month)

    # Plot histogram
    fig = pyplot.figure()
    pyplot.title('Weather Events in Bloomington 2012')
    pyplot.xlabel('Month')
    pyplot.ylabel('Event Count')
    pyplot.axes().yaxis.grid()

    num_months = max_month - min_month + 1;
    bins = np.arange(1, num_months + 2)  # Need extra bin
    pyplot.hist(event_months, bins=bins, label=event_types)

    # Align month labels to bin centers
    month_names = calendar.month_name[min_month:max_month+1]
    pyplot.xticks(bins + 0.5, month_names)

    pyplot.legend()
    
    return fig

#-------------------------------------------------- 

# Read data and extract dates, temperatures, and events
data = read_weather(os.path.join('data', 'weather.csv'))

min_temps = data['min temp']
mean_temps = data['mean temp']
max_temps = data['max temp']
dates = [datetime.fromordinal(d) for d in data['timestamp']]
events = data['events']

# Do plotting
if not os.path.exists('plots'):
    os.mkdir('plots')

fig = temp_plot(dates, mean_temps)
fig.savefig(os.path.join('plots', 'day_vs_temp.png'))

fig = temp_plot(dates, mean_temps, min_temps, max_temps)
fig.savefig(os.path.join('plots', 'day_vs_temp-all.png'))

fig = hist_events(dates, events)
fig.savefig(os.path.join('plots', 'event_histogram.png'))
